# Lumen — photo & video sharing app

Ekta full-stack Next.js app: sign up/login, photo/video upload, feed, likes,
comments, follow, ar profile page. UI Instagram-er inspiration e banano, kintu
alada branding/design (dark "darkroom" theme + EXIF-style metadata stamp).

## 1) Prerequisites

- Node.js 18+ (`node -v` diye check koro)
- MongoDB — ei duita option er ekta:
  - **Local**: MongoDB Community Server install koro (mongodb.com/try/download/community), ba Docker: `docker run -d -p 27017:27017 --name lumen-mongo mongo`
  - **Free cloud (easier)**: MongoDB Atlas e (mongodb.com/cloud/atlas/register) free cluster banao, connection string collect koro.

## 2) Install

```bash
cd lumen
npm install
```

## 3) Environment variables

`.env.local.example` file ta copy kore `.env.local` banao:

```bash
cp .env.local.example .env.local
```

Tarpor `.env.local` open kore:
- `MONGODB_URI` — local hole `mongodb://127.0.0.1:27017/lumen`, Atlas hole oder deya connection string.
- `JWT_SECRET` — je kono lomba random string (login session secure rakhar jonno).

## 4) Run (development)

```bash
npm run dev
```

Browser e http://localhost:3000 open koro. Prothome `/register` diye ekta
account banao — automatically login hoye feed e chole jabe.

## 5) Production build (optional, deploy korar age)

```bash
npm run build
npm start
```

## Kon file kothay ache

- `app/` — shob page (feed, login, register, upload, profile) ar API routes (`app/api/...`)
- `models/` — MongoDB schema (User, Post)
- `lib/` — DB connection, auth (JWT + cookie), file upload helper
- `components/` — Nav bar, PostCard
- `public/uploads/` — upload kora shob photo/video ekhane save hoy (disk e). Deploy
  korar somoy — jodi Vercel er moto serverless platform e deploy koro tahole disk
  storage persistent thake na, tokhon Cloudinary/S3 er moto cloud storage lagbe.
  Nijer VPS (chotokhato Ubuntu server) e host korle eita already kaj korbe as-is.

## Features included

- Email/username + password auth (bcrypt + JWT httpOnly cookie)
- Photo/video upload (jpg, png, webp, gif, mp4, webm, mov — 25MB limit)
- Ranked feed — log-scaled engagement (likes/comments/views) + a gentle
  time-decay + a per-day seeded shuffle, so it doesn't repeat and doesn't
  feel like a plain chronological list
- **Reels page** (`/reels`) — fullscreen, swipe/scroll-snap vertical video
  feed, autoplay-on-view, tap to mute/unmute, like/comment overlay, same
  ranking algorithm applied to videos only
- Like/unlike posts, view count per post
- Comments: add, edit (author only), delete (comment author OR the post
  owner), like a comment
- Delete your own posts (also removes the media file from disk) — from the
  feed's "…" menu, the profile grid, or a reel
- Edit profile: display name, username, bio, profile photo — plus a quick
  "Upload" button right on your own profile page
- Change password
- Delete your own account (cascades: removes your posts, your comments
  everywhere, and cleans you out of other people's likes/followers/following)
- Follow/unfollow, profile page with post grid, follower/following count
- Toast notifications (react-toastify) for success/error feedback and for
  delete confirmations, instead of native browser alert()/confirm() popups

## Ja pore add kora jete pare

- Explore/search page, hashtags
- Stories (24h auto-expire)
- Direct messages
- Notifications
- Image resizing/compression on upload
- Cloud storage (S3/Cloudinary) for production deploys
