"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { ImagePlus, Loader2 } from "lucide-react";
import { notifyError, notifySuccess } from "@/lib/toast";

export default function UploadPage() {
  const router = useRouter();
  const inputRef = useRef(null);
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState("");
  const [caption, setCaption] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function handleFile(f) {
    if (!f) return;
    setFile(f);
    setPreview(URL.createObjectURL(f));
    setError("");
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!file) {
      setError("Choose a photo or video first.");
      notifyError("Choose a photo or video first.");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const form = new FormData();
      form.append("media", file);
      form.append("caption", caption);
      const res = await fetch("/api/posts", { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Could not upload your post.");
        notifyError(data.error);
        setLoading(false);
        return;
      }
      notifySuccess("Shared to your feed.");
      router.push("/");
      router.refresh();
    } catch {
      setError("Network error. Try again.");
      notifyError("Network error. Try again.");
      setLoading(false);
    }
  }

  const isVideo = file?.type?.startsWith("video");

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      <h1 className="font-display text-3xl mb-1" style={{ color: "var(--text)" }}>
        New frame
      </h1>
      <p className="font-mono text-xs mb-6" style={{ color: "var(--muted)" }}>
        jpg · png · webp · gif · mp4 · webm — up to 25MB
      </p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div
          onClick={() => inputRef.current?.click()}
          className="rounded-2xl border-2 border-dashed flex items-center justify-center cursor-pointer overflow-hidden aspect-square"
          style={{ borderColor: "var(--border)", background: "var(--surface)" }}
        >
          {preview ? (
            isVideo ? (
              <video src={preview} controls className="w-full h-full object-contain" />
            ) : (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={preview} alt="Preview" className="w-full h-full object-contain" />
            )
          ) : (
            <div className="flex flex-col items-center gap-2" style={{ color: "var(--muted)" }}>
              <ImagePlus size={36} strokeWidth={1.5} />
              <span className="text-sm">Tap to choose a photo or video</span>
            </div>
          )}
        </div>
        <input
          ref={inputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,video/quicktime"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />

        <textarea
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder="Write a caption…"
          rows={3}
          maxLength={2200}
          className="w-full px-4 py-3 rounded-xl text-sm outline-none border resize-none"
          style={{ background: "var(--surface)", borderColor: "var(--border)", color: "var(--text)" }}
        />

        {error && (
          <p className="text-sm font-mono" style={{ color: "var(--accent)" }}>
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={loading}
          className="w-full py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-60"
          style={{ background: "var(--accent)", color: "#14120f" }}
        >
          {loading && <Loader2 size={16} className="animate-spin" />}
          {loading ? "Sharing…" : "Share"}
        </button>
      </form>
    </div>
  );
}
