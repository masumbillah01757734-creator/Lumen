"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { Aperture, Upload, LogOut, User as UserIcon, Clapperboard, Shield } from "lucide-react";

export default function Nav({ user }) {
  const router = useRouter();

  async function handleLogout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  if (!user) return null;

  return (
    <header
      className="sticky top-0 z-20 border-b backdrop-blur"
      style={{ borderColor: "var(--border)", background: "rgba(20,18,15,0.85)" }}
    >
      <div className="max-w-3xl mx-auto flex items-center justify-between px-4 h-16">
        <Link href="/" className="flex items-center gap-2 group">
          <Aperture
            size={26}
            strokeWidth={1.5}
            style={{ color: "var(--accent)" }}
            className="transition-transform group-hover:rotate-45 duration-500"
          />
          <span className="font-display text-2xl tracking-tight" style={{ color: "var(--text)" }}>
            Lumen
          </span>
        </Link>

        <nav className="flex items-center gap-1">
          <Link
            href="/reels"
            className="flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium transition-colors hover:bg-[var(--surface-2)]"
            style={{ color: "var(--text)" }}
          >
            <Clapperboard size={18} strokeWidth={1.75} />
            <span className="hidden sm:inline">Reels</span>
          </Link>
          <Link
            href="/upload"
            className="flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium transition-colors hover:bg-[var(--surface-2)]"
            style={{ color: "var(--text)" }}
          >
            <Upload size={18} strokeWidth={1.75} />
            <span className="hidden sm:inline">Upload</span>
          </Link>
          {(user.role === "moderator" || user.role === "admin") && (
            <Link
              href="/dashboard"
              className="flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium transition-colors hover:bg-[var(--surface-2)]"
              style={{ color: "var(--text)" }}
            >
              <Shield size={18} strokeWidth={1.75} />
              <span className="hidden sm:inline">Admin</span>
            </Link>
          )}
          <Link
            href={`/profile/${user.username}`}
            className="flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium transition-colors hover:bg-[var(--surface-2)]"
            style={{ color: "var(--text)" }}
          >
            {user.avatar ? (
              <span className="w-[18px] h-[18px] rounded-full overflow-hidden inline-block">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={user.avatar} alt="" className="w-full h-full object-cover" />
              </span>
            ) : (
              <UserIcon size={18} strokeWidth={1.75} />
            )}
            <span className="hidden sm:inline">{user.username}</span>
          </Link>
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-2 rounded-full text-sm font-medium transition-colors hover:bg-[var(--surface-2)]"
            style={{ color: "var(--muted)" }}
          >
            <LogOut size={18} strokeWidth={1.75} />
          </button>
        </nav>
      </div>
    </header>
  );
}